package com.medication.research.service;

import com.medication.research.model.Drug;
import com.medication.research.repository.DrugRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DrugService {

    private DrugRepository drugRepository;

    public DrugService(DrugRepository drugRepository) {
        this.drugRepository = drugRepository;
    }

    public Iterable<Drug> list() {
        return drugRepository.findAll();
    }

    public List<Drug> saveAll(List<Drug> drugs) {
        List<Drug> response = (List<Drug>) drugRepository.saveAll(drugs);
        return response;
    }

    public Drug save(Drug drug) {
        return drugRepository.save(drug);
    }
}
