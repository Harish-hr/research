package com.medication.research.repository;

import com.medication.research.model.Drug;
import org.springframework.data.repository.CrudRepository;

public interface DrugRepository extends CrudRepository<Drug, String> {

}
