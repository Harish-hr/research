package com.medication.research.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.ArrayList;
@Data
@Entity
public class Drug {
    @Id
    public String id;
    public ArrayList<String> diseases;
    @Column(name="description",length=1000)
    public String description;
    public String name;
    public String released;
}
