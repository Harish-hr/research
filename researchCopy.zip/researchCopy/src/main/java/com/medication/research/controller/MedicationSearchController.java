package com.medication.research.controller;

import com.medication.research.service.DrugService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public class MedicationSearchController {

    @Autowired private DrugService drugService;

    public MedicationSearchController(DrugService drugService) {
        this.drugService = drugService;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/medicationinfo")
    public List<String> getAllMedicationSearchResults(@RequestParam String searchText) {
        //medicationSearchService.getDrugs();
        return null;
    }
}
