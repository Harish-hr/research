package com.medication.research;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medication.research.model.Drug;
import com.medication.research.model.Root;
import com.medication.research.service.DrugService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class MedicationResearchApiApplication {

  public static void main(String[] args) {
    SpringApplication.run(MedicationResearchApiApplication.class, args);
  }

  @Bean
  CommandLineRunner runner(DrugService drugService) {
    return args -> {
      ObjectMapper mapper = new ObjectMapper();
      TypeReference<List<Drug>> typeReference = new TypeReference<List<Drug>>() {};
      InputStream inputStream = TypeReference.class.getResourceAsStream("/json/dataSet.json");
      try {
        File resource = new ClassPathResource("json/dataSet.json").getFile();
        String text = new String(Files.readAllBytes(resource.toPath()));
        Root lang = mapper.readValue(text, Root.class);
        List<Root> drugList = new ArrayList(Arrays.asList(lang));
        if (!drugList.isEmpty()) {
          List<Drug> d = drugList.get(0).getDrugs();
          drugService.saveAll(d);
        }
        System.out.println("Users Saved!");
      } catch (IOException e) {
        System.out.println("Unable to save users: " + e.getMessage());
      }
    };
  }
}
